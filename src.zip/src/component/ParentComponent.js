
// import React, { useState } from 'react';
// import ReportSubmissionForm from './ReportSubmissionForm';
// import ReportListPage from './ReportListPage';

// function ParentComponent() {
//   const [reports, setReports] = useState([]); // State to store reports

//   // Function to add a new report to the state
//   const addReport = (newReport) => {
//     setReports([...reports, newReport]);
//   };

//   return (
//     <div>
//       <ReportSubmissionForm onReportSubmit={addReport} />
//       <ReportListPage reportsData={reports} />
//     </div>
//   );
// }

// export default ParentComponent;
